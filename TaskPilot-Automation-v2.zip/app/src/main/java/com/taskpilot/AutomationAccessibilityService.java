package com.taskpilot;

import android.accessibilityservice.AccessibilityService;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;

public class AutomationAccessibilityService extends AccessibilityService {
    public static AutomationAccessibilityService instance;

    @Override public void onServiceConnected() { instance=this; }
    @Override public void onAccessibilityEvent(AccessibilityEvent event) { }
    @Override public void onInterrupt() { }
    @Override public void onDestroy() { instance=null; super.onDestroy(); }

    public boolean clickText(String text) {
        AccessibilityNodeInfo root=getRootInActiveWindow();
        if(root==null) return false;
        for(AccessibilityNodeInfo n:root.findAccessibilityNodeInfosByText(text)){
            if(n.isClickable()) return n.performAction(AccessibilityNodeInfo.ACTION_CLICK);
            AccessibilityNodeInfo p=n.getParent();
            if(p!=null && p.isClickable()) return p.performAction(AccessibilityNodeInfo.ACTION_CLICK);
        }
        return false;
    }

    public void openApp(String packageName) {
        try {
            Intent i=getPackageManager().getLaunchIntentForPackage(packageName);
            if(i!=null){ i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); startActivity(i); }
        } catch(Exception ignored){}
    }

    public boolean setText(AccessibilityNodeInfo node,String value) {
        if(node==null) return false;
        Bundle b=new Bundle();
        b.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE,value);
        return node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT,b);
    }
}
