package com.taskpilot;

import android.app.*;
import android.os.*;
import android.content.*;
import android.provider.Settings;
import android.view.*;
import android.widget.*;
import java.util.*;

public class MainActivity extends Activity {
    LinearLayout list;
    EditText task, target;
    TimePicker time;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        buildUi();
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission("android.permission.POST_NOTIFICATIONS") != 0)
            requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"}, 10);
    }

    void buildUi() {
        ScrollView scroll = new ScrollView(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(24,24,24,24);

        TextView title = new TextView(this);
        title.setText("TaskPilot\nAutomation v2");
        title.setTextSize(28);
        root.addView(title);

        TextView info = new TextView(this);
        info.setText("\nTask लिखें, समय चुनें और schedule करें.\nदूसरे apps में automation के लिए Accessibility Service को Android Settings में manually enable करना होगा.");
        info.setTextSize(16);
        root.addView(info);

        task = new EditText(this);
        task.setHint("Task: जैसे WhatsApp खोलना");
        root.addView(task);

        target = new EditText(this);
        target.setHint("Optional: जिस app का package पता हो");
        root.addView(target);

        time = new TimePicker(this);
        time.setIs24HourView(true);
        root.addView(time);

        Button schedule = new Button(this);
        schedule.setText("Schedule Task");
        root.addView(schedule);

        Button accessibility = new Button(this);
        accessibility.setText("Enable Automation Service");
        root.addView(accessibility);

        Button test = new Button(this);
        test.setText("Test Notification");
        root.addView(test);

        TextView h = new TextView(this);
        h.setText("\nScheduled tasks");
        h.setTextSize(21);
        root.addView(h);

        list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        root.addView(list);

        schedule.setOnClickListener(v -> {
            String s = task.getText().toString().trim();
            if (s.isEmpty()) { Toast.makeText(this,"पहले Task लिखें",Toast.LENGTH_SHORT).show(); return; }
            int h1=time.getHour(), m=time.getMinute();
            scheduleTask(s, target.getText().toString().trim(), h1, m);
            addTaskRow(s,h1,m);
            task.setText(""); target.setText("");
        });

        accessibility.setOnClickListener(v -> {
            try { startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)); }
            catch(Exception e) { Toast.makeText(this,"Accessibility Settings नहीं खुलीं",Toast.LENGTH_SHORT).show(); }
        });

        test.setOnClickListener(v -> notifyNow("TaskPilot","Automation service is ready."));
        scroll.addView(root);
        setContentView(scroll);
    }

    void addTaskRow(String s,int h,int m){
        TextView t=new TextView(this);
        t.setText("✓ "+s+"  •  "+String.format(Locale.getDefault(),"%02d:%02d",h,m));
        t.setTextSize(18); t.setPadding(0,16,0,16); list.addView(t);
    }

    void scheduleTask(String text,String target,int h,int m){
        Calendar c=Calendar.getInstance();
        c.set(Calendar.HOUR_OF_DAY,h); c.set(Calendar.MINUTE,m); c.set(Calendar.SECOND,0); c.set(Calendar.MILLISECOND,0);
        if(c.before(Calendar.getInstance())) c.add(Calendar.DAY_OF_YEAR,1);
        Intent i=new Intent(this,TaskReceiver.class);
        i.putExtra("text",text); i.putExtra("target",target);
        int id=(int)(System.currentTimeMillis() & 0x7fffffff);
        PendingIntent p=PendingIntent.getBroadcast(this,id,i,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        AlarmManager am=(AlarmManager)getSystemService(ALARM_SERVICE);
        am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,c.getTimeInMillis(),p);
        Toast.makeText(this,"Task scheduled",Toast.LENGTH_SHORT).show();
    }

    void notifyNow(String title,String text){
        if(Build.VERSION.SDK_INT>=33 && checkSelfPermission("android.permission.POST_NOTIFICATIONS")!=0){
            requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"},10); return;
        }
        NotificationManager n=(NotificationManager)getSystemService(NOTIFICATION_SERVICE);
        if(Build.VERSION.SDK_INT>=26) n.createNotificationChannel(new NotificationChannel("tasks","Tasks",NotificationManager.IMPORTANCE_DEFAULT));
        n.notify((int)System.currentTimeMillis(),
            new Notification.Builder(this,"tasks").setContentTitle(title).setContentText(text)
            .setSmallIcon(android.R.drawable.ic_dialog_info).setAutoCancel(true).build());
    }
}
