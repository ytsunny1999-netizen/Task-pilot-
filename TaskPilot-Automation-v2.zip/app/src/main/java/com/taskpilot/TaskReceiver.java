package com.taskpilot;

import android.content.*;
import android.app.*;

public class TaskReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context c, Intent i) {
        String s=i.getStringExtra("text");
        String target=i.getStringExtra("target");
        NotificationManager n=(NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE);
        if(android.os.Build.VERSION.SDK_INT>=26)
            n.createNotificationChannel(new NotificationChannel("tasks","Tasks",NotificationManager.IMPORTANCE_DEFAULT));
        String msg=(s==null?"Scheduled task":s);
        if(target!=null && !target.isEmpty()) msg += " • target: "+target;
        n.notify((int)System.currentTimeMillis(),
            new Notification.Builder(c,"tasks").setContentTitle("TaskPilot Automation")
            .setContentText(msg).setSmallIcon(android.R.drawable.ic_dialog_info).setAutoCancel(true).build());
    }
}
