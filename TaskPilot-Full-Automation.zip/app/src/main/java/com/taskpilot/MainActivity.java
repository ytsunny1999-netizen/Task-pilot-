package com.taskpilot;
import android.app.*; import android.os.*; import android.content.*; import android.view.*; import android.widget.*; import java.util.*;
public class MainActivity extends Activity {
 LinearLayout list; ArrayList<String> tasks=new ArrayList<>();
 public void onCreate(Bundle b){super.onCreate(b); build();}
 void build(){
  LinearLayout r=new LinearLayout(this); r.setOrientation(LinearLayout.VERTICAL); r.setPadding(24,24,24,24);
  TextView h=new TextView(this); h.setText("TaskPilot ⚙\nAutomation"); h.setTextSize(27); r.addView(h);
  EditText name=new EditText(this); name.setHint("Task ka naam"); r.addView(name);
  TimePicker tp=new TimePicker(this); tp.setIs24HourView(true); r.addView(tp);
  Button add=new Button(this); add.setText("Schedule Task"); r.addView(add);
  list=new LinearLayout(this); list.setOrientation(LinearLayout.VERTICAL); r.addView(list);
  add.setOnClickListener(v->{String s=name.getText().toString().trim(); if(s.isEmpty())return; int hh=tp.getHour(),mm=tp.getMinute(); schedule(s,hh,mm); TextView t=new TextView(this); t.setText("✓ "+s+"  •  "+String.format("%02d:%02d",hh,mm)); t.setTextSize(18); t.setPadding(0,16,0,16); list.addView(t); name.setText("");});
  Button test=new Button(this); test.setText("Test Notification"); r.addView(test); test.setOnClickListener(v->notifyNow("TaskPilot","Automation test successful")); setContentView(r);
 }
 void schedule(String text,int h,int m){Calendar c=Calendar.getInstance(); c.set(Calendar.HOUR_OF_DAY,h);c.set(Calendar.MINUTE,m);c.set(Calendar.SECOND,0);if(c.before(Calendar.getInstance()))c.add(Calendar.DAY_OF_YEAR,1); Intent i=new Intent(this,TaskReceiver.class);i.putExtra("text",text); PendingIntent p=PendingIntent.getBroadcast(this,(int)System.currentTimeMillis(),i,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE); ((AlarmManager)getSystemService(ALARM_SERVICE)).setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,c.getTimeInMillis(),p);}
 void notifyNow(String title,String text){if(Build.VERSION.SDK_INT>=33&&checkSelfPermission("android.permission.POST_NOTIFICATIONS")!=0)requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"},5); NotificationManager n=(NotificationManager)getSystemService(NOTIFICATION_SERVICE); if(Build.VERSION.SDK_INT>=26)n.createNotificationChannel(new NotificationChannel("tasks","Tasks",NotificationManager.IMPORTANCE_DEFAULT)); n.notify((int)System.currentTimeMillis(),new Notification.Builder(this,"tasks").setContentTitle(title).setContentText(text).setSmallIcon(android.R.drawable.ic_dialog_info).build());}
}