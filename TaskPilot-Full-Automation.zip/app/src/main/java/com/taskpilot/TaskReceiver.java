package com.taskpilot;
import android.content.*; import android.app.*;
public class TaskReceiver extends BroadcastReceiver {
 public void onReceive(Context c,Intent i){String s=i.getStringExtra("text"); NotificationManager n=(NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE); if(android.os.Build.VERSION.SDK_INT>=26)n.createNotificationChannel(new NotificationChannel("tasks","Tasks",NotificationManager.IMPORTANCE_DEFAULT)); n.notify((int)System.currentTimeMillis(),new Notification.Builder(c,"tasks").setContentTitle("TaskPilot Automation").setContentText(s==null?"Scheduled task":s).setSmallIcon(android.R.drawable.ic_dialog_info).build());}
}